﻿using System;
using System.Collections.Generic;

namespace Group8
{
    public class Instructor : Person
    {
        private List<double> evaluations;


        public override double Rating
        {
            get
            {
                double sum = 0;
                foreach (double eval in evaluations)
                {
                    sum += eval;
                }
                return sum / evaluations.Count;
            }
        }

        public Instructor(string name, List<double> grades) : base(name)
        {
            this.evaluations = new List<double>(grades);
        }
    }
}
